
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
 
import java.io.*;
import java.util.*;
import org.json.simple.*;
import org.json.simple.parser.*;
import com.codoid.products.exception.FilloException;

public class Olayjson {
	
	public static void main(String[] args)

	{
		String emailid="";
		String password="";
		String confpassword="";
		String Day="";
		String Month="";
		String Year="";
			System.setProperty("webdriver.chrome.driver","E:\\chromedriver_win32 (1)\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			 JavascriptExecutor js = (JavascriptExecutor) driver;
			 String baseUrl = "https://www.olay.co.uk/en-gb";
		        String expectedTitle ="Olay: Skin Care Products & Tips for All Skin Types"; 
		        String actualTitle = "";
		        driver.get(baseUrl);
		        actualTitle = driver.getTitle();
		        if (actualTitle.contentEquals(expectedTitle)){
		            System.out.println("Test Passed!");
		        } else {
		            System.out.println("Test Failed");
		        }
		        
		      //JSON parser object to parse read file
		       
				JSONParser parser = new JSONParser();
		        try 
		        {
		        	Object obj = parser.parse(new FileReader("D:\\OPrograms\\Sel\\Input.json"));
		            JSONObject jsonObject = (JSONObject)obj;
		             emailid = (String)jsonObject.get("UserName");
		             password = (String)jsonObject.get("Password");
		             confpassword = (String)jsonObject.get("Confpass");
		             Day = (String)jsonObject.get("Day");
		             //Day = (long)jsonObject.get("Day");
		             Month = (String)jsonObject.get("Month");
		             Year = (String)jsonObject.get("year");
		            
		            System.out.println("Emailid: " + emailid);
		            System.out.println("pwd: " + password);
		            System.out.println("cpwd: " + confpassword);
		            System.out.println("day: " + Day);
		            System.out.println("mo: " + Month);
		            System.out.println("yr: " + Year);
		            
		           
		           
		         } 
		        catch(Exception e) 
		        {
		            e.printStackTrace();
		        }
		        
		        WebElement Register = driver.findElement(By.xpath("//a[contains(text(),'Register')]"));
		        Register.click();	
		        
		        WebElement username = driver.findElement(By.xpath("//input[@data-key=\"emailAddress\"]"));
		        username.sendKeys(emailid);
		        WebElement password1 = driver.findElement(By.xpath("//input[@data-key=\"newPassword\"]"));
		        password1.sendKeys(password);
		        WebElement confirmpassword = driver.findElement(By.xpath("//input[@validationregexerror=\"Password and Confirm Password values must match. Please try again.\"]")); 
		        confirmpassword.sendKeys(confpassword);
		        
		        //To enter date of birth
		        WebElement dayy=driver.findElement(By.xpath("//select[@data-key=\"birthdate[dateselect_day]\"]"));
		        //Select date = new Select(day);
		        dayy.sendKeys(Day);
		        WebElement mo=driver.findElement(By.xpath("//select[@data-key=\"birthdate[dateselect_month]\"]"));
		        //Select month = new Select(mo);
		        mo.sendKeys(Month);
		        WebElement yr=driver.findElement(By.xpath("//select[@data-key=\"birthdate[dateselect_year]\"]"));
		        //Select year = new Select(yr);
		        yr.sendKeys(Year);
		        driver.manage().window().maximize();
		        WebElement Regiandcreateprofile = driver.findElement(By.xpath("//input[@value=\"REGISTER AND CREATE YOUR PROFILE\"]"));
		        Regiandcreateprofile.click();
		        driver.close();
		}

}

