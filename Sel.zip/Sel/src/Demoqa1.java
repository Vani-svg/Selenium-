import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
public class Demoqa1 {
	public static void main(String[] args) {
        
    	System.setProperty("webdriver.chrome.driver","E:\\chromedriver_win32 (1)\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		 JavascriptExecutor js = (JavascriptExecutor) driver;
    	
        String baseUrl = "https://demoqa.com/selectable/";
        String expectedTitle = "Selectable � ToolsQA � Demo Website to Practice Automation";
        String actualTitle = "";

       
        driver.get(baseUrl);
        actualTitle = driver.getTitle();

        
        if (actualTitle.contentEquals(expectedTitle)){
            System.out.println("Test Passed!");
        } else {
            System.out.println("Test Failed");
        }
        WebElement Item1 = driver.findElement(By.xpath("//*[@id=\"selectable\"]/li[1]"));	
        Item1.click();	
        String first=Item1.getText();
        System.out.println("First Item Name:"+first);
        
        WebElement Item2 = driver.findElement(By.xpath("//*[@id=\"selectable\"]/li[2]"));	
        Item2.click();	
        String second=Item2.getText();
        System.out.println("Second Item Name:"+second);
        
        WebElement Item3 = driver.findElement(By.xpath("//*[@id=\"selectable\"]/li[3]"));	
        Item3.click();	
        String third=Item3.getText();
        System.out.println("Third Item Name:"+third);
        
        WebElement Item4 = driver.findElement(By.xpath("//*[@id=\"selectable\"]/li[4]"));	
        Item4.click();	
        String fourth=Item4.getText();
        System.out.println("Fourth Item Name:"+fourth);

        WebElement Item5 = driver.findElement(By.xpath("//*[@id=\"selectable\"]/li[5]"));	
        Item5.click();	
        String fifth=Item5.getText();
        System.out.println("Fifth Item Name:"+fifth);
        
        WebElement Item6 = driver.findElement(By.xpath("//*[@id=\"selectable\"]/li[6]"));	
        Item6.click();	
        String Sixth=Item6.getText();
        System.out.println("Sixth Item Name:"+Sixth);
        
        WebElement Item7 = driver.findElement(By.xpath("//*[@id=\"selectable\"]/li[7]"));	
        Item7.click();	
        String Seventh=Item7.getText();
        System.out.println("Seveth Item Name:"+Seventh);
        
        driver.close();



}
}
