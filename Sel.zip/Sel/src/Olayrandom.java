import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
public class Olayrandom {
public static void main(String[] args) {
	

        
    	System.setProperty("webdriver.chrome.driver","E:\\chromedriver_win32 (1)\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		 JavascriptExecutor js = (JavascriptExecutor) driver;
    	
        String baseUrl = "https://www.olay.co.uk/en-gb";
        String expectedTitle ="Olay: Skin Care Products & Tips for All Skin Types"; 
        String actualTitle = "";

        
        driver.get(baseUrl);
        actualTitle = driver.getTitle();

        
        if (actualTitle.contentEquals(expectedTitle)){
            System.out.println("Test Passed!");
        } else {
            System.out.println("Test Failed");
        }
       
       
        WebElement Register = driver.findElement(By.xpath("//a[contains(text(),'Register')]"));
        Register.click();
        Random randomGenerator = new Random(); 
        int randomInt = randomGenerator.nextInt(1000);  
        WebElement username = driver.findElement(By.xpath("//input[@data-key=\"emailAddress\"]"));
        username.sendKeys("ban"+randomInt+"@gmail.com");
         WebElement password = driver.findElement(By.xpath("//input[@data-key=\"newPassword\"]"));
        password.sendKeys("aaaa@1234");
        WebElement confirmpassword = driver.findElement(By.xpath("//input[@validationregexerror=\"Password and Confirm Password values must match. Please try again.\"]")); 
        confirmpassword.sendKeys("aaaa@1234");
        
        //To enter date of birth
        WebElement day=driver.findElement(By.xpath("//select[@data-key=\"birthdate[dateselect_day]\"]"));
        Select date = new Select(day);
        date.selectByIndex(2);
        WebElement mo=driver.findElement(By.xpath("//select[@data-key=\"birthdate[dateselect_month]\"]"));
        Select month = new Select(mo);
        month.selectByIndex(2);
        WebElement yr=driver.findElement(By.xpath("//select[@data-key=\"birthdate[dateselect_year]\"]"));
        Select year = new Select(yr);
        year.selectByIndex(9);
        driver.manage().window().maximize();
        WebElement Regiandcreateprofile = driver.findElement(By.xpath("//input[@value=\"REGISTER AND CREATE YOUR PROFILE\"]"));
        Regiandcreateprofile.click();
        driver.close();
}
}



