import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
	import org.openqa.selenium.Keys;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.interactions.Actions;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.Select;
	import org.openqa.selenium.support.ui.WebDriverWait;

public class Demoqa3 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			System.setProperty("webdriver.chrome.driver","E:\\chromedriver_win32 (1)\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/droppable/");


		String expectedUrl="https://demoqa.com/droppable/";
		String actualUrl=driver.getCurrentUrl();
		System.out.println(actualUrl);
		if(actualUrl.contentEquals(expectedUrl))
		{
		System.out.println("Pass");
		}

		  else
		       {
		  System.out.println("Fail");
		       }



	driver.findElement(By.xpath("//a[contains(text(),'Droppable')]")).click();
	   String ActualText=driver.findElement(By.xpath("//*[@class='ui-widget-header ui-droppable']")).getText();
	   String ExpectedText="Drop here";
	   if(ActualText.contentEquals(ExpectedText))
	{
	System.out.println("Pass");
	}

	  else
	       {
	  System.out.println("Fail");
	       }
	   WebElement From=driver.findElement(By.xpath("//*[@class='ui-widget-content ui-draggable ui-draggable-handle']"));
	   WebElement To=driver.findElement(By.xpath("//*[@class='ui-widget-header ui-droppable']"));
	   Actions act=new Actions(driver);
	   act.dragAndDrop(From, To).build().perform();
	 
	   
	   String ExpectedafterDrop= "Dropped!";
	   String Actualafterterdrop= driver.findElement(By.xpath("//*[@class='ui-widget-header ui-droppable ui-state-highlight']//*[text()='Dropped!']")).getText();
	   
	   if(Actualafterterdrop.contentEquals(ExpectedafterDrop))
	{
	System.out.println("Pass");
	}

	  else
	       {
	  System.out.println("Fail");
	       }
	}
}
