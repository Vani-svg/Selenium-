import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
	import org.openqa.selenium.Keys;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.interactions.Actions;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.Select;
	import org.openqa.selenium.support.ui.WebDriverWait;

public class Demoqa6car {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			System.setProperty("webdriver.chrome.driver","E:\\chromedriver_win32 (1)\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/controlgroup/");


		String expectedUrl="https://demoqa.com/controlgroup/";
		String actualUrl=driver.getCurrentUrl();
		System.out.println(actualUrl);
		if(actualUrl.contentEquals(expectedUrl))
		{
		System.out.println("Pass");
		}

		  else
		       {
		  System.out.println("Fail");
		       }
		driver.manage().window().maximize();



driver.findElement(By.xpath("//a[contains(text(),'Controlgroup')]")).click();
driver.findElement(By.xpath("//*[@id=\"content\"]/div[2]/div/fieldset[1]/div/label[1]/span[2]")).click();

driver.findElement(By.xpath("//*[@id=\"content\"]/div[2]/div/fieldset[1]/div/label[3]/span[1]")).click();
driver.findElement(By.xpath("//*[@id=\"content\"]/div[2]/div/fieldset[1]/div/span[2]/a[1]/span[1]")).click();

driver.findElement(By.xpath("//button[text()='Book Now!']")).click();
//Select drpCountry5 = new Select(driver.findElement(By.xpath("//*[@id='car-type-button']")));
//drpCountry5.selectByVisibleText("Full size car");
	}
}
