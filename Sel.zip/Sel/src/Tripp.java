
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
public class Tripp {
	public static void main(String[] args) {
		        
		    	System.setProperty("webdriver.chrome.driver","E:\\chromedriver_win32 (1)\\chromedriver.exe");
				WebDriver driver = new ChromeDriver();
				 JavascriptExecutor js = (JavascriptExecutor) driver;
		    	
		        String baseUrl = "https://www.makemytrip.com";
		        String expectedTitle = "MakeMyTrip - #1 Travel Website 50% OFF on Hotels, Flights & Holiday";
		        String actualTitle = "";

		        
		        driver.get(baseUrl);
		        
		        actualTitle = driver.getTitle();

		        
		        if (actualTitle.contentEquals(expectedTitle)){
		            System.out.println("Test Passed!");
		        } else {
		            System.out.println("Test Failed");
		        }
		        
		        WebElement radio1 = driver.findElement(By.xpath("//div[@class=\"minContainer\"]/div/div/div/ul/li[2]"));	
		        radio1.click();	
		        WebElement fromcity=driver.findElement(By.xpath("//input[@id=\"fromCity\"]"));
		        fromcity.click();
		        WebElement Element=driver.findElement(By.xpath("//*[@id=\"react-autowhatever-1-section-0-item-1\"]/div/div[1]/p[1]"));
		       Element.click();
		        WebElement Tocity=driver.findElement(By.xpath("//input[@id=\"toCity\"]"));
		        WebElement Element1=driver.findElement(By.xpath("//*[@id=\"react-autowhatever-1-section-0-item-0\"]/div/div[1]/p[1]"));
		        Element1.click();
		        driver.manage().window().maximize();
		        WebElement departure=driver.findElement(By.xpath("//input[@id=\"departure\"]"));
		        //departure.click();
		        WebElement depdate=driver.findElement(By.xpath("//div[@aria-label=\"Fri Apr 17 2020\"]/div/p[1]"));
		        depdate.click();
		        Actions action = new Actions(driver);
		        action.sendKeys(Keys.ESCAPE).build().perform();
		        WebElement search=driver.findElement(By.xpath("//a[contains(text(),'Search')]"));
		        search.click();
		        //WebElement viewfare=driver.findElement(By.xpath("//*[@id=\"ow-domrt-jrny\"]/div/div[1]/label/div[1]/span[1]"));
		        //viewfare.click();
		        WebElement viewfare1=driver.findElement(By.xpath("//button[@class=\"fli_primary_btn text-uppercase \"]"));
		        viewfare1.click();
		     driver.close();
		       
		    }

		
		

	}

