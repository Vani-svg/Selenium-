import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
	import org.openqa.selenium.Keys;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.interactions.Actions;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.Select;
	import org.openqa.selenium.support.ui.WebDriverWait;
public class Demoqa4 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			System.setProperty("webdriver.chrome.driver","E:\\chromedriver_win32 (1)\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/selectmenu/");


		String expectedUrl="https://demoqa.com/selectmenu/";
		String actualUrl=driver.getCurrentUrl();
		System.out.println(actualUrl);
		if(actualUrl.contentEquals(expectedUrl))
		{
		System.out.println("Pass");
		}

		  else
		       {
		  System.out.println("Fail");
		       }
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//a[contains(text(),'Selectmenu')]")).click();
		   Select drpCountry1 = new Select(driver.findElement(By.xpath("//*[@id='speed-button']")));
		drpCountry1.selectByVisibleText("Medium");
		Select drpCountry2 = new Select(driver.findElement(By.xpath("//*[@id='files-button']")));
		drpCountry2.selectByVisibleText("jQuery.js");
		Select drpCountry3 = new Select(driver.findElement(By.xpath("//*[@id='number-button']")));
		drpCountry3.selectByVisibleText("2");
		Select drpCountry4 = new Select(driver.findElement(By.xpath("//select[@id=\'salutation\']")));
		drpCountry4.selectByVisibleText("Mr.");
		
		driver.close();

}
}


