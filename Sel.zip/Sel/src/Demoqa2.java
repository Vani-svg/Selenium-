import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
	import org.openqa.selenium.Keys;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.interactions.Actions;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.Select;
	import org.openqa.selenium.support.ui.WebDriverWait;

	public class Demoqa2 {

	public static void main(String[] args) {
	// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","E:\\chromedriver_win32 (1)\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.get("https://demoqa.com");


	String expectedUrl="https://demoqa.com/html-contact-form/";
	String actualUrl=driver.getCurrentUrl();
	System.out.println(actualUrl);
	if(actualUrl.contentEquals(expectedUrl))
	{
	System.out.println("Pass");
	}

	  else
	       {
	  System.out.println("Fail");
	       }


	 
	   //Enter FirstName
	   driver.findElement(By.xpath("//a[contains(text(),'HTML contact form')]")).click();
	   driver.findElement(By.xpath("//input[@class='firstname']")).sendKeys("Sarah");
	   driver.findElement(By.xpath("//input[ @id='lname']")).sendKeys("vani");
	   driver.findElement(By.xpath("//input[ @name='country']")).sendKeys("India");
	   
	   driver.manage().window().maximize();
	   driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	   ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
	   driver.switchTo().window(tabs.get(0));
	   driver.findElement(By.partialLinkText("Google L")).click();
	   driver.navigate().back(); 
	   
	   driver.findElement(By.partialLinkText("here")).click();
	   driver.switchTo().window(tabs.get(0));
	   driver.navigate().back(); 
	    driver.findElement(By.xpath("//*[ @name='subject']")).sendKeys("This is DemoQA Project");
	   driver.findElement(By.xpath("//input[ @type='submit']")).click();
	   driver.close();
	   }
	
	}


