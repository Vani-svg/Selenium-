import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class OlayGermany {

public static void main(String[] args) {
// TODO Auto-generated method stub
	
	System.setProperty("webdriver.chrome.driver","E:\\chromedriver_win32 (1)\\chromedriver.exe");
WebDriver driver=new ChromeDriver();
JavascriptExecutor js = (JavascriptExecutor) driver;
driver.get("https://www.olaz.de/de-de");
driver.findElement(By.linkText("Registrieren")).click();
driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_imgfemale\"]")).click();
driver.findElement(By.xpath("//*[contains(@id,'grs_consumer[firstname]')]")).sendKeys("Vani");
driver.findElement(By.xpath("//*[contains(@id,'grs_consumer[lastname]')]")).sendKeys("panchu");
driver.findElement(By.xpath("//input[@data-key=\"emailAddress\"]")).sendKeys("abc@def.com");
driver.findElement(By.xpath("//*[contains(@id,'account[password][password]')]")).sendKeys("vanipanchu@123");
driver.findElement(By.xpath("//*[contains(@id,'account[password][confirm]')]")).sendKeys("vanipanchu@123");
Select drpCountry1 = new Select(driver.findElement(By.xpath("//*[contains(@id,'[birthdate][day]')]")));
drpCountry1.selectByVisibleText("19");
Select drpCountry2 = new Select(driver.findElement(By.xpath("//*[contains(@id,'[birthdate][month]')]")));
drpCountry2.selectByVisibleText("8");
Select drpCountry3 = new Select(driver.findElement(By.xpath("//*[contains(@id,'consumer[birthdate][year]')]")));
drpCountry3.selectByVisibleText("2006");
Select drpCountry4 = new Select(driver.findElement(By.xpath("//*[contains(@id,'[addresses][0][country]')]")));
drpCountry4.selectByVisibleText("Deutschland");
driver.findElement(By.xpath("//*[contains(@id,'[addresses][0][line1]')]")).sendKeys("123");
driver.findElement(By.xpath("//*[contains(@id,'[addresses][0][postalarea]')]")).sendKeys("45645678");
driver.findElement(By.xpath("//*[contains(@id,'[addresses][0][city]')]")).sendKeys("789");
driver.manage().window().maximize();
js.executeScript("window.scrollBy(0,1500)");
driver.findElement(By.xpath("//input[@class='button-link button']")).click();
}
}

