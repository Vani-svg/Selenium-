import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import com.codoid.products.exception.FilloException;

import com.codoid.products.fillo.Connection;
 
import com.codoid.products.fillo.Fillo;
 
import com.codoid.products.fillo.Recordset;
public class Olayexcel {
	public static void main(String[] args)throws InterruptedException, FilloException 

{
		System.setProperty("webdriver.chrome.driver","E:\\chromedriver_win32 (1)\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 String baseUrl = "https://www.olay.co.uk/en-gb";
	        String expectedTitle ="Olay: Skin Care Products & Tips for All Skin Types"; 
	        String actualTitle = "";
	        driver.get(baseUrl);
	        actualTitle = driver.getTitle();
	        if (actualTitle.contentEquals(expectedTitle)){
	            System.out.println("Test Passed!");
	        } else {
	            System.out.println("Test Failed");
	        }
		 
		//Locating the Test data excel file
			String excelPath = "D:\\OPrograms\\Sel\\Datasheet.xlsx";
			System.out.println(excelPath);
			//Create an Object of Fillo Class
		    Fillo fillo = new Fillo();
		    
		  //Create an Object for Connection class and use getConnection()
		    Connection connection = fillo.getConnection(excelPath);
		    //Select all the values present in a sheet
		    String strSelectQuerry = "Select * from  Data";
		    System.out.println(strSelectQuerry);
		    
		  //Execute the Select query 
		    	Recordset recordset =null;
		        recordset = connection.executeQuery(strSelectQuerry);
		   //use while loop to iterate through all columns and rows 
		    while(recordset.next())
		    {
		      String Emailid = recordset.getField("Email");
		      System.out.println("Email is:"+Emailid);
		      String Password=recordset.getField("Password");
		      System.out.println("Password is:"+Password);
		      String ConfPassword=recordset.getField("Confirm Password");
		      System.out.println("Conf Password is:"+ConfPassword);
		      String Dayy=recordset.getField("Day");
		      System.out.println("Day:"+Dayy);
		      String Monthh=recordset.getField("Month");
		      System.out.println("Month:"+Monthh);
		      String Yearr=recordset.getField("Year");
		      System.out.println("Year:"+Yearr);
    	
        
        
        WebElement Register = driver.findElement(By.xpath("//a[contains(text(),'Register')]"));
        Register.click();	
        
        WebElement username = driver.findElement(By.xpath("//input[@data-key=\"emailAddress\"]"));
        username.sendKeys(Emailid);
        WebElement password = driver.findElement(By.xpath("//input[@data-key=\"newPassword\"]"));
        password.sendKeys(Password);
        WebElement confirmpassword = driver.findElement(By.xpath("//input[@validationregexerror=\"Password and Confirm Password values must match. Please try again.\"]")); 
        confirmpassword.sendKeys(ConfPassword);
        
        //To enter date of birth
        WebElement day=driver.findElement(By.xpath("//select[@data-key=\"birthdate[dateselect_day]\"]"));
        //Select date = new Select(day);
        day.sendKeys(Dayy);
        WebElement mo=driver.findElement(By.xpath("//select[@data-key=\"birthdate[dateselect_month]\"]"));
        //Select month = new Select(mo);
        mo.sendKeys(Monthh);
        WebElement yr=driver.findElement(By.xpath("//select[@data-key=\"birthdate[dateselect_year]\"]"));
        //Select year = new Select(yr);
        yr.sendKeys(Yearr);
        driver.manage().window().maximize();
        WebElement Regiandcreateprofile = driver.findElement(By.xpath("//input[@value=\"REGISTER AND CREATE YOUR PROFILE\"]"));
        Regiandcreateprofile.click();
        driver.close();
}
}
}

